# CLScroll
【Unity】文字スクロール表示

https://user-images.githubusercontent.com/49199105/120921950-5632da00-c701-11eb-91f5-a2c7b42762d8.mp4
